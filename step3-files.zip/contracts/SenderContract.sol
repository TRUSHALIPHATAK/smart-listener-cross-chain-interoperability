// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/**
 * @title SenderContract
 * @notice Source-chain contract for the Smart Listener cross-chain protocol.
 *         Emits a `TransactionSent` event that the three independent off-chain
 *         Smart Listeners monitor and vote on (2-of-3 approval required).
 *
 * @dev Step 3 (optimistic execution + rollback, as in the Smart Listeners paper):
 *      the sender's state change (escrowed value) is applied IMMEDIATELY. If the
 *      destination does not confirm completion before the rollback window (delta_A)
 *      expires, an authorised Listener calls rollback() and the value is refunded.
 *      If the destination completes in time, a Listener calls finalize().
 *      The Receiver refuses late executions (deadline < delta_A), so a transaction
 *      can never be both rolled back here and executed there.
 */
contract SenderContract {
    // ── Events ───────────────────────────────────────────────────────────────

    /**
     * @notice Emitted when a cross-chain transfer is requested.
     * @param txId          Unique transaction identifier (keccak256 of sender+nonce+timestamp)
     * @param sender        Address that initiated the transfer
     * @param destinationChainId  Target chain identifier (e.g., Fabric channel name hash)
     * @param destinationAddress  Encoded recipient on the destination chain
     * @param payload       ABI-encoded call data / token transfer data
     * @param nonce         Per-sender nonce for replay protection
     * @param timestamp     Block timestamp of the request
     */
    event TransactionSent(
        bytes32 indexed txId,
        address indexed sender,
        bytes32 indexed destinationChainId,
        bytes   destinationAddress,
        bytes   payload,
        uint256 nonce,
        uint256 timestamp
    );

    /**
     * @notice Emitted when a previously submitted tx is cancelled by its sender.
     */
    event TransactionCancelled(bytes32 indexed txId, address indexed sender);

    /// @notice Destination confirmed completion in time; the optimistic state is now permanent.
    event TransactionFinalized(bytes32 indexed txId, address indexed listener);

    /// @notice Destination did not complete within delta_A; the sender was refunded.
    event TransactionRolledBack(
        bytes32 indexed txId,
        address indexed sender,
        uint256 amount,
        address indexed listener
    );

    // ── State ─────────────────────────────────────────────────────────────────

    /// @notice Nonce per sender (prevents replay at source layer)
    mapping(address => uint256) public nonces;

    /// @notice Owner of the contract (can pause in emergency)
    address public immutable owner;

    /// @notice Whether the contract is paused
    bool public paused;

    /// @notice txId → sender (for cancel validation)
    mapping(bytes32 => address) public txSenders;

    // ── Step 3: optimistic escrow + rollback ──────────────────────────────────

    enum TxState { None, Pending, Finalized, RolledBack }

    struct Escrow {
        address sender;
        uint256 amount;
        uint256 rollbackAfter; // timestamp after which rollback becomes possible (delta_A)
        TxState state;
    }

    mapping(bytes32 => Escrow) public escrows;

    /// @notice Source-chain accounts of the Smart Listener nodes allowed to settle
    mapping(address => bool) public isListener;

    /// @notice delta_A in seconds
    uint256 public rollbackWindow;
    bool public configured;

    // ── Errors ────────────────────────────────────────────────────────────────

    error NotListener();
    error AlreadyConfigured();
    error NotPending();
    error RollbackWindowOpen();
    error RefundFailed();

    error ContractPaused();
    error EmptyDestinationAddress();
    error EmptyPayload();
    error NotTxSender();
    error TxAlreadyCancelled();

    // ── Modifiers ─────────────────────────────────────────────────────────────

    modifier whenNotPaused() {
        if (paused) revert ContractPaused();
        _;
    }

    modifier onlyListener() {
        if (!isListener[msg.sender]) revert NotListener();
        _;
    }

    modifier onlyOwner() {
        require(msg.sender == owner, "SenderContract: not owner");
        _;
    }

    // ── Constructor ───────────────────────────────────────────────────────────

    constructor() {
        owner = msg.sender;
    }

    // ── External Functions ────────────────────────────────────────────────────

    /**
     * @notice Initiates a cross-chain transfer.
     * @param destinationChainId  Target chain ID (arbitrary bytes32 agreed with Listeners)
     * @param destinationAddress  Encoded address / channel / key on destination
     * @param payload             ABI-encoded payload for the destination contract
     * @return txId               The unique transaction ID
     */
    function sendCrossChainTransaction(
        bytes32 destinationChainId,
        bytes calldata destinationAddress,
        bytes calldata payload
    ) external payable whenNotPaused returns (bytes32 txId) {
        if (destinationAddress.length == 0) revert EmptyDestinationAddress();
        if (payload.length == 0) revert EmptyPayload();

        uint256 nonce = nonces[msg.sender]++;

        txId = keccak256(
            abi.encodePacked(
                msg.sender,
                nonce,
                block.timestamp,
                destinationChainId,
                destinationAddress,
                payload,
                block.chainid
            )
        );

        txSenders[txId] = msg.sender;

        // Optimistic state change: value is escrowed right away
        escrows[txId] = Escrow({
            sender: msg.sender,
            amount: msg.value,
            rollbackAfter: block.timestamp + rollbackWindow,
            state: TxState.Pending
        });

        emit TransactionSent(
            txId,
            msg.sender,
            destinationChainId,
            destinationAddress,
            payload,
            nonce,
            block.timestamp
        );
    }

    /**
     * @notice Cancel an unexecuted tx (signal only — off-chain Listeners honour this).
     */
    function cancelTransaction(bytes32 txId) external {
        if (txSenders[txId] != msg.sender) revert NotTxSender();
        if (txSenders[txId] == address(0)) revert TxAlreadyCancelled();

        delete txSenders[txId];
        emit TransactionCancelled(txId, msg.sender);
    }

    /**
     * @notice Destination completed in time: make the optimistic state permanent.
     */
    function finalize(bytes32 txId) external onlyListener {
        Escrow storage e = escrows[txId];
        if (e.state != TxState.Pending) revert NotPending();
        e.state = TxState.Finalized;
        emit TransactionFinalized(txId, msg.sender);
    }

    /**
     * @notice Destination did not complete within delta_A: undo the optimistic state change.
     */
    function rollback(bytes32 txId) external onlyListener {
        Escrow storage e = escrows[txId];
        if (e.state != TxState.Pending) revert NotPending();
        if (block.timestamp <= e.rollbackAfter) revert RollbackWindowOpen();

        e.state = TxState.RolledBack; // effects before interaction
        uint256 amount = e.amount;
        address to = e.sender;

        if (amount > 0) {
            (bool ok, ) = payable(to).call{value: amount}("");
            if (!ok) revert RefundFailed();
        }
        emit TransactionRolledBack(txId, to, amount, msg.sender);
    }

    // ── Admin ─────────────────────────────────────────────────────────────────

    /**
     * @notice One-time setup: authorised Listener accounts and the rollback window.
     */
    function configure(address[] calldata listeners, uint256 window) external onlyOwner {
        if (configured) revert AlreadyConfigured();
        configured = true;
        rollbackWindow = window;
        for (uint256 i = 0; i < listeners.length; i++) {
            isListener[listeners[i]] = true;
        }
    }

    function setPaused(bool _paused) external onlyOwner {
        paused = _paused;
    }

    // ── View ──────────────────────────────────────────────────────────────────

    function getNonce(address sender) external view returns (uint256) {
        return nonces[sender];
    }
}
