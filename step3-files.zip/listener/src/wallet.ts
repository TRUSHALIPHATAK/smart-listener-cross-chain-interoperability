/**
 * wallet.ts — per-listener signer.
 * Listener A..D use Hardhat accounts #1..#4 (local demo mnemonic). The same
 * addresses are authorised on both chains (Sender listeners / Receiver executors).
 */
import { ethers } from "ethers";
import { EXECUTOR_MNEMONIC, LISTENER_ID } from "./config";
import { LISTENER_IDS } from "./types";

export function listenerIndex(): number {
  return LISTENER_IDS.indexOf(LISTENER_ID);
}

/** Provider with a pinned network: a down chain gives clean per-call errors, no retry storms. */
export function makeProvider(rpcUrl: string, chainId: number): ethers.JsonRpcProvider {
  const network = ethers.Network.from(chainId);
  return new ethers.JsonRpcProvider(rpcUrl, network, { staticNetwork: network });
}

export function listenerSigner(rpcUrl: string, chainId: number): { signer: ethers.NonceManager; address: string } {
  const provider = makeProvider(rpcUrl, chainId);
  const hd = ethers.HDNodeWallet.fromPhrase(
    EXECUTOR_MNEMONIC,
    undefined,
    `m/44'/60'/0'/0/${listenerIndex() + 1}`
  );
  return { signer: new ethers.NonceManager(hd.connect(provider)), address: hd.address };
}
