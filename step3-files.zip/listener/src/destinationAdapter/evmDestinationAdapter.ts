/**
 * evmDestinationAdapter.ts — REAL EVM destination adapter (Step 1)
 *
 * Sends an actual transaction to DestinationReceiver on the destination chain.
 * Each Listener signs with its own account (Hardhat account #1..#4 for A..D) so
 * parallel listeners never collide on a nonce.
 */

import { ethers } from "ethers";
import { CrossChainTransaction, DestinationResult } from "../types";
import { childLogger } from "../logger";
import {
  DEST_RPC_URL,
  DESTINATION_RECEIVER_ADDRESS,
  DELTA_B_SECONDS,
  DEST_CHAIN_ID,
} from "../config";
import { listenerSigner } from "../wallet";

const log = childLogger("evmDestinationAdapter");

const RECEIVER_ABI = [
  "function execute(bytes32 sourceTxId, bytes payload, uint256 deadline)",
  "error NotExecutor()",
  "error AlreadyExecuted()",
  "error EmptyPayload()",
  "error DeadlineExpired()",
  "function wasExecuted(bytes32 txId) view returns (bool)",
  "event InterChainCompleted(bytes32 indexed sourceTxId, address indexed executor, bytes32 payloadHash, uint256 timestamp)",
];

let receiver: ethers.Contract | null = null;

function getReceiver(): ethers.Contract {
  if (receiver) return receiver;
  if (!DESTINATION_RECEIVER_ADDRESS) {
    throw new Error("DestinationReceiver address missing. Run: npx hardhat run scripts/deployDestination.ts --network destination");
  }
  const { signer, address } = listenerSigner(DEST_RPC_URL, DEST_CHAIN_ID); // A->#1, B->#2, C->#3, D->#4
  log.info({ executor: address, destRpc: DEST_RPC_URL, receiver: DESTINATION_RECEIVER_ADDRESS }, "EVM destination ready");
  receiver = new ethers.Contract(DESTINATION_RECEIVER_ADDRESS, RECEIVER_ABI, signer);
  return receiver;
}

function toHexBytes(payload: string): string {
  return ethers.isHexString(payload) ? payload : ethers.hexlify(ethers.toUtf8Bytes(payload));
}

export async function evmExecute(tx: CrossChainTransaction): Promise<DestinationResult> {
  const start = Date.now();
  try {
    const c = getReceiver();

    // Idempotent retry: if an earlier attempt already landed, return its real hash.
    if (await c.wasExecuted(tx.txId)) {
      const logs = await c.queryFilter(c.filters.InterChainCompleted(tx.txId));
      const hash = logs.length > 0 ? logs[0].transactionHash : undefined;
      log.info({ txId: tx.txId, destTxHash: hash }, "Already executed on destination");
      return { success: true, destTxHash: hash, latencyMs: Date.now() - start };
    }

    // delta_B: the Receiver refuses this tx after (source timestamp + delta_B)
    const deadline = Math.floor(tx.sourceTimestamp / 1000) + DELTA_B_SECONDS;
    const response = await c.execute(tx.txId, toHexBytes(tx.payload), deadline);
    const receipt = await response.wait();
    if (!receipt || receipt.status !== 1) {
      return { success: false, errorMessage: "Destination transaction reverted" };
    }
    const latencyMs = Date.now() - start;
    log.info({ txId: tx.txId, destTxHash: receipt.hash, latencyMs }, "Executed on destination chain");
    return { success: true, destTxHash: receipt.hash, latencyMs };
  } catch (err) {
    const msg = (err as { shortMessage?: string }).shortMessage ?? (err as Error).message;
    log.warn({ txId: tx.txId, msg }, "EVM destination execution failed");
    return { success: false, errorMessage: `EVM destination error: ${msg}` };
  }
}

/** Read-only: has the destination executed this tx? (and the real hash, if so) */
export async function findCompletion(txId: string): Promise<{ executed: boolean; hash?: string }> {
  const c = getReceiver();
  if (!(await c.wasExecuted(txId))) return { executed: false };
  const logs = await c.queryFilter(c.filters.InterChainCompleted(txId));
  return { executed: true, hash: logs.length > 0 ? logs[0].transactionHash : undefined };
}
