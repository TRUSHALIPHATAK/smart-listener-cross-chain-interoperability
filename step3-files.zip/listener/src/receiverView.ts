/**
 * receiverView.ts — read-only view of the DESTINATION chain for the dashboard.
 */
import { ethers } from "ethers";
import { DEST_RPC_URL, DEST_CHAIN_ID, DESTINATION_RECEIVER_ADDRESS } from "./config";
import { makeProvider } from "./wallet";

const ABI = [
  "function executedCount() view returns (uint256)",
  "event InterChainCompleted(bytes32 indexed sourceTxId, address indexed executor, bytes32 payloadHash, uint256 timestamp)",
];

export interface ReceiverSummary {
  deployed: boolean;
  reachable: boolean;
  address: string;
  chainId?: string;
  rpc: string;
  executedCount?: number;
  latestBlock?: number;
  recent: { txId: string; executor: string; destTxHash: string; blockNumber: number; timestamp: number }[];
  error?: string;
}

export async function getReceiverSummary(limit = 15): Promise<ReceiverSummary> {
  const base: ReceiverSummary = {
    deployed: Boolean(DESTINATION_RECEIVER_ADDRESS),
    reachable: false,
    address: DESTINATION_RECEIVER_ADDRESS,
    rpc: DEST_RPC_URL,
    recent: [],
  };
  if (!DESTINATION_RECEIVER_ADDRESS) return { ...base, error: "DestinationReceiver not deployed" };

  const provider = makeProvider(DEST_RPC_URL, DEST_CHAIN_ID);
  try {
    const contract = new ethers.Contract(DESTINATION_RECEIVER_ADDRESS, ABI, provider);
    const [net, latest, count] = await Promise.all([
      provider.getNetwork(),
      provider.getBlockNumber(),
      contract.executedCount(),
    ]);
    const logs = await contract.queryFilter(contract.filters.InterChainCompleted(), Math.max(0, latest - 5000), latest);
    const recent = logs
      .filter((l): l is ethers.EventLog => "args" in l)
      .slice(-limit)
      .reverse()
      .map((l) => ({
        txId: String(l.args[0]),
        executor: String(l.args[1]),
        destTxHash: l.transactionHash,
        blockNumber: l.blockNumber,
        timestamp: Number(l.args[3]),
      }));
    return {
      ...base,
      reachable: true,
      chainId: net.chainId.toString(),
      executedCount: Number(count),
      latestBlock: latest,
      recent,
    };
  } catch (err) {
    return { ...base, error: (err as Error).message.slice(0, 160) };
  } finally {
    provider.destroy();
  }
}
