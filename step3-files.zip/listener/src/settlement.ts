/**
 * settlement.ts — Step 3: optimistic execution + rollback (source side).
 *
 * The source chain applies the sender's state change immediately (escrow). Every
 * few seconds each Listener reconciles recent transactions against the chain:
 *
 *   - destination completed in time  -> finalize()  (state becomes permanent)
 *   - delta_A expired, not completed -> rollback()  (sender refunded)
 *
 * The Receiver refuses executions after delta_B < delta_A, so the two outcomes
 * can never both happen. One Listener per tx acts first ("primary"); the others
 * act only after a grace period (backup), so a crashed primary cannot block settlement.
 */

import { ethers } from "ethers";
import { DbAdapter } from "./db";
import { childLogger } from "./logger";
import { CrossChainTransaction, TxStatus } from "./types";
import {
  SOURCE_RPC_URL, SOURCE_CHAIN_ID, SENDER_CONTRACT_ADDRESS, TOTAL_LISTENERS, BACKUP_GRACE_SECONDS,
} from "./config";
import { findCompletion } from "./destinationAdapter/evmDestinationAdapter";
import { listenerIndex, listenerSigner } from "./wallet";

const log = childLogger("settlement");

export enum EscrowState { None = 0, Pending = 1, Finalized = 2, RolledBack = 3 }

const SENDER_ABI = [
  "function escrows(bytes32) view returns (address sender, uint256 amount, uint256 rollbackAfter, uint8 state)",
  "function isListener(address) view returns (bool)",
  "function finalize(bytes32 txId)",
  "function rollback(bytes32 txId)",
];

/** Statuses that can still become EXECUTED (completion seen on the destination) */
const NOT_FINAL: TxStatus[] = ["PENDING", "VOTED", "APPROVED", "EXECUTING", "FAILED", "TIMED_OUT"];
/** Statuses that can end as ROLLED_BACK (everything except EXECUTED) */
const ROLLBACKABLE: TxStatus[] = [...NOT_FINAL, "REJECTED"];

export interface EscrowInfo {
  state: EscrowState;
  amount: bigint;
  rollbackAfter: number;
}

export class SourceSettlement {
  private contract: ethers.Contract | null = null;
  private address = "";

  private ensure(): ethers.Contract {
    if (!this.contract) {
      if (!SENDER_CONTRACT_ADDRESS) throw new Error("SenderContract address missing");
      const { signer, address } = listenerSigner(SOURCE_RPC_URL, SOURCE_CHAIN_ID);
      this.address = address;
      this.contract = new ethers.Contract(SENDER_CONTRACT_ADDRESS, SENDER_ABI, signer);
    }
    return this.contract;
  }

  /** Is this Listener primary for the tx? (deterministic, spreads work across nodes) */
  isPrimaryFor(txId: string): boolean {
    return parseInt(txId.slice(2, 10), 16) % TOTAL_LISTENERS === listenerIndex();
  }

  async checkAuthorized(): Promise<void> {
    const c = this.ensure();
    const ok: boolean = await c.isListener(this.address);
    if (ok) log.info({ listener: this.address }, "Authorised to settle on the source chain");
    else log.error({ listener: this.address }, "NOT authorised on SenderContract - rollback/finalize will fail. Re-run scripts/deploy.ts");
  }

  async getEscrow(txId: string): Promise<EscrowInfo> {
    const e = await this.ensure().escrows(txId);
    return { state: Number(e.state) as EscrowState, amount: BigInt(e.amount), rollbackAfter: Number(e.rollbackAfter) };
  }

  private async send(fn: "finalize" | "rollback", txId: string): Promise<void> {
    const c = this.ensure();
    try {
      // Fixed gas limit: skip eth_estimateGas, which can simulate against a stale block
      // timestamp and wrongly report "window still open" right after delta_A expires.
      const tx = await c[fn](txId, { gasLimit: 200_000n });
      await tx.wait();
    } catch (err) {
      // Another Listener may have settled it first: that is fine.
      const now = await this.getEscrow(txId);
      if (now.state !== EscrowState.Pending) return;
      throw err;
    }
  }

  finalize(txId: string) { return this.send("finalize", txId); }
  rollback(txId: string) { return this.send("rollback", txId); }
}

/** One reconciliation pass over the most recent transactions. */
export async function reconcileOnce(db: DbAdapter, settlement: SourceSettlement): Promise<void> {
  const txs = await db.listTransactions({ limit: 200 });
  for (const tx of txs) {
    if (tx.status === "ROLLED_BACK") continue;
    try {
      await reconcileTx(db, settlement, tx);
    } catch (err) {
      log.warn({ txId: tx.txId, err: (err as Error).message }, "Reconcile failed (will retry)");
    }
  }
}

export async function reconcileTx(db: DbAdapter, s: SourceSettlement, tx: CrossChainTransaction): Promise<void> {
  const esc = await s.getEscrow(tx.txId);
  if (esc.state === EscrowState.None) return;

  if (esc.state === EscrowState.Finalized) {
    if (tx.status !== "EXECUTED") await db.transitionStatus(tx.txId, NOT_FINAL, "EXECUTED");
    return;
  }

  if (esc.state === EscrowState.RolledBack) {
    await db.transitionStatus(tx.txId, ROLLBACKABLE, "ROLLED_BACK");
    return;
  }

  // ── Pending on the source chain ───────────────────────────────────────────
  const nowSec = Math.floor(Date.now() / 1000);
  const primary = s.isPrimaryFor(tx.txId);
  const grace = primary ? 0 : BACKUP_GRACE_SECONDS;

  if (tx.status === "EXECUTED") {
    // Destination confirmed -> make the optimistic state permanent
    if (nowSec - Math.floor(tx.updatedAt / 1000) >= grace) {
      await s.finalize(tx.txId);
      log.info({ txId: tx.txId }, "Finalized on source chain");
    }
    return;
  }

  if (nowSec <= esc.rollbackAfter + grace) return; // delta_A window still open

  // Window over. Did the destination complete in time after all? (Receiver refuses late executions.)
  const done = await findCompletion(tx.txId);
  if (done.executed) {
    await db.transitionStatus(tx.txId, NOT_FINAL, "EXECUTED", { destTxHash: done.hash });
    await s.finalize(tx.txId);
    log.info({ txId: tx.txId }, "Destination had completed in time - finalized");
    return;
  }

  // Destination never completed -> undo the optimistic source-side state change
  await s.rollback(tx.txId);
  await db.transitionStatus(tx.txId, ROLLBACKABLE, "ROLLED_BACK");
  log.warn(
    { txId: tx.txId, refunded: ethers.formatEther(esc.amount), previousStatus: tx.status },
    "ROLLED BACK: destination did not complete within delta_A - sender refunded"
  );
}
